<img src="icon512.png?raw=true" width="75" align="left">

# [Image Replacer](https://chrome.google.com/webstore/detail/image-replacer/kjdfnmkplcjchfjealepndkfjgcgonib)
Replace all images with whatever you want.
